module.exports.descriptors = [
    'aaaa',
    'bbbb',
    'cccc',
    'dddd',
    'eeee',
    'ffff',
    'gggg',
    'hhhh',
    'iiii',
    'jjjj'
]

module.exports.places = [
    'Tawian',
    'Taipei',
    'New Taipei',
    'Tauan',
    'Xindru',
    'Miuli',
    'Taichung',
    'Chuang Hua',
    'Ulin'
]

